cd /jiliang_monitor/monitor_server
/root/anaconda3/bin/python run.py
/root/anaconda3/bin/python /debug.py
/bin/bash
