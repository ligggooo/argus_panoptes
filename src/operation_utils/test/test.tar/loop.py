import time

while 1:
  time.sleep(1)
  print(1)
